import machine
import ssd1306
import time

led_vermelho = machine.Pin(25, machine.Pin.OUT)
led_verde = machine.Pin(26, machine.Pin.OUT)

botao_vermelho = machine.Pin(12, machine.Pin.IN, machine.Pin.PULL_UP)
botao_azul = machine.Pin(14, machine.Pin.IN, machine.Pin.PULL_UP)
botao_amarelo = machine.Pin(27, machine.Pin.IN, machine.Pin.PULL_UP)
botao_preto = machine.Pin(33, machine.Pin.IN, machine.Pin.PULL_UP)

i2c = machine.I2C(0, scl=machine.Pin(22), sda=machine.Pin(21))
oled_largura = 128
oled_tamanho = 64
oled = ssd1306.SSD1306_I2C(oled_largura, oled_tamanho, i2c)

servo1 = machine.PWM(machine.Pin(18), freq=50)
servo2 = machine.PWM(machine.Pin(19), freq=50)
servo3 = machine.PWM(machine.Pin(23), freq=50)

servos = {1: servo1, 2: servo2, 3: servo3}

def mover_servo(servo, angulo):
    pmin = 26
    pmax = 128
    calculo = int(pmin + (angulo / 180) * (pmax - pmin))
    servo.duty(calculo)

def atualizar_leds(status):
    if status == "Liberada":
        led_verde.on()
        led_vermelho.off()
    else:
        led_vermelho.on()
        led_verde.off()

def atualizar_tela(porta, status):
    oled.fill(0)
    oled.text("Sistema de Acesso", 0, 0)

    if porta == 1:
        oled.text("Porta 1", 0, 15)
        oled.text("Lab Informatica", 0, 30)
    elif porta == 2:
        oled.text("Porta 2", 0, 15)
        oled.text("Sala Professores", 0, 30)
    elif porta == 3:
        oled.text("Porta 3", 0, 15)
        oled.text("Almoxarifado", 0, 30)

    oled.text("Status: " + status, 0, 45)
    oled.show()

porta_selecionada = 1
status_portas = {1: "Bloqueada", 2: "Bloqueada", 3: "Bloqueada"}

for servo in servos.values():
    mover_servo(servo, 0)
atualizar_leds(status_portas[porta_selecionada])
atualizar_tela(porta_selecionada, status_portas[porta_selecionada])

while True:

    if botao_vermelho.value() == 0:
        porta_selecionada = 1
        atualizar_leds(status_portas[porta_selecionada])
        atualizar_tela(porta_selecionada, status_portas[porta_selecionada])
        time.sleep(0.3)

    elif botao_azul.value() == 0:
        porta_selecionada = 2
        atualizar_leds(status_portas[porta_selecionada])
        atualizar_tela(porta_selecionada, status_portas[porta_selecionada])
        time.sleep(0.3)

    elif botao_amarelo.value() == 0:
        porta_selecionada = 3
        atualizar_leds(status_portas[porta_selecionada])
        atualizar_tela(porta_selecionada, status_portas[porta_selecionada])
        time.sleep(0.3)

    elif botao_preto.value() == 0:
        if status_portas[porta_selecionada] == "Bloqueada":
            status_portas[porta_selecionada] = "Liberada"
            mover_servo(servos[porta_selecionada], 90)
        else:
            status_portas[porta_selecionada] = "Bloqueada"
            mover_servo(servos[porta_selecionada], 0)

        atualizar_leds(status_portas[porta_selecionada])
        atualizar_tela(porta_selecionada, status_portas[porta_selecionada])
        time.sleep(0.3)

    time.sleep(0.1)
