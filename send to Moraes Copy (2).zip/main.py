import machine
import ssd1306
import time


led_vermelho = machine.Pin(25, machine.Pin.OUT)
led_azul = machine.Pin(26, machine.Pin.OUT)

botao_vermelho = machine.Pin(14, machine.Pin.IN, machine.Pin.PULL_UP)
botao_azul = machine.Pin(12, machine.Pin.IN, machine.Pin.PULL_UP)
botao_amarelo = machine.Pin(13, machine.Pin.IN, machine.Pin.PULL_UP)
botao_verde = machine.Pin(27, machine.Pin.IN, machine.Pin.PULL_UP)


i2c = machine.I2C(0, scl=machine.Pin(22), sda=machine.Pin(21))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)


servo = machine.PWM(machine.Pin(18))
servo.freq(50)

def mover_servo(angulo):
    pulso_min = 26
    pulso_max = 123
    duty = int(pulso_min + (angulo / 180) * (pulso_max - pulso_min))
    servo.duty(duty)

def mostrar_mensagem(linha1, linha2=""):
    oled.fill(0)
    oled.text(linha1, 0, 10)
    oled.text(linha2, 0, 30)
    oled.show()


mover_servo(90)
mostrar_mensagem("Sistema Pronto")

while True:


    if botao_azul.value() == 0:
        mostrar_mensagem("ACESSO", "BLOQUEADO")
        led_azul.on()
        mover_servo(0)

        time.sleep(0.5)

        led_azul.off()


    elif botao_vermelho.value() == 0:
        mostrar_mensagem("ACESSO", "NEGADO")

        for i in range(3):
            led_vermelho.on()
            time.sleep(0.2)
            led_vermelho.off()
            time.sleep(0.2)

    elif botao_verde.value() == 0:
        mostrar_mensagem("ACESSO", "LIBERADO")
        led_azul.on()

        mover_servo(180)

        time.sleep(2)

        led_azul.off()

    elif botao_amarelo.value() == 0:
        mostrar_mensagem("REINICIANDO", "SISTEMA")

        led_vermelho.off()
        led_azul.off()

        mover_servo(90)

        time.sleep(1)

        mostrar_mensagem("Sistema Pronto")

    time.sleep(0.1)